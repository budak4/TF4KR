//my secript by @RafzModsDeveloper
//not sale this script

require("./database/module")

//GLOBAL PAYMENT
global.storename = "RafzModsDeveloper"
global.dana = "6283845850116"
global.qris = "-"


// GLOBAL SETTING
global.owner = "6283845850116"
global.namabot = "🩸⃟𒆜𝐑𝐚𝐟𝐳𝐌𝐨𝐝𝐬𝟗𝟗𝟗⃟╳〽️"
global.nomorbot = "6283845850116"
global.namaCreator = "🩸⃟𒆜𝐑𝐚𝐟𝐳𝐌𝐨𝐝𝐬𝟗𝟗𝟗⃟╳〽️"
global.linkyt = "https://www.youtube.com/@RafzMods999"
global.autoJoin = false
global.antilink = false
global.versisc = '30'

// DELAY JPM
global.delayjpm = 5500



//GLOBAL THUMB

global.codeInvite = ""
global.imageurl = 'https://deposit.pictures/p/8f3f4ab89de24d3faef51146d7439b3a'
global.isLink = "https://whatsapp.com/channel/0029VaddFi3ISTkTUM8Vdb0b"
global.packname = "Bugs"
global.author = "RafzMods"
global.jumlah = "5"


let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})